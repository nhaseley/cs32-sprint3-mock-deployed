import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2014939b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/App.css";
import BodyContents from "/src/components/BodyContents.tsx";
function App() {
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "App-header", children: /* @__PURE__ */ jsxDEV("h1", { children: "Mock" }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
      lineNumber: 8,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
      lineNumber: 7,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "App-description", children: [
      /* @__PURE__ */ jsxDEV("h3", { children: [
        "With this front-end application, we offer you the opportunity to load, view, and search for instances in CSVs in ",
        /* @__PURE__ */ jsxDEV("i", { children: "our mocked data" }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
          lineNumber: 12,
          columnNumber: 51
        }, this),
        "."
      ] }, void 0, true, {
        fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "You can choose view your command history in one of two ways:",
        " ",
        /* @__PURE__ */ jsxDEV("b", { children: "Brief mode" }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
          lineNumber: 15,
          columnNumber: 11
        }, this),
        " will display the results for all previous commands run. ",
        /* @__PURE__ */ jsxDEV("b", { children: "Verbose mode" }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
          lineNumber: 16,
          columnNumber: 16
        }, this),
        " will display both the commands and results for all previous commands run."
      ] }, void 0, true, {
        fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
        lineNumber: 13,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "To load, please enter the command ",
        /* @__PURE__ */ jsxDEV("b", { children: "load CSV_FILEPATH" }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
          lineNumber: 20,
          columnNumber: 45
        }, this),
        ". To view, please enter the command ",
        /* @__PURE__ */ jsxDEV("b", { children: "view" }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
          lineNumber: 21,
          columnNumber: 36
        }, this),
        ". To search, please enter the command ",
        /* @__PURE__ */ jsxDEV("b", { children: "search COLUMN_NAME SEARCH_TERM" }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
          lineNumber: 22,
          columnNumber: 19
        }, this),
        ". Alternatively, you can search with the command",
        /* @__PURE__ */ jsxDEV("b", { children: " search COLUMN_INDEX SEARCH_TERM" }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
          lineNumber: 24,
          columnNumber: 11
        }, this),
        ". Have fun!"
      ] }, void 0, true, {
        fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(BodyContents, {}, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVE7QUFSUixPQUFPLG9CQUFtQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQixPQUFPQSxrQkFBa0I7QUFHekIsU0FBU0MsTUFBTTtBQUNiLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwyQkFBQyxPQUFFLFdBQVUsY0FDWCxpQ0FBQyxRQUFHLG9CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsNkJBQUMsUUFBRztBQUFBO0FBQUEsUUFDc0MsdUJBQUMsT0FBRSwrQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtCO0FBQUEsUUFBSTtBQUFBLFdBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFDaUU7QUFBQSxNQUNqRSx1QkFBQyxPQUFDO0FBQUE7QUFBQSxRQUM2RDtBQUFBLFFBQzdELHVCQUFDLE9BQUUsMEJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFBSTtBQUFBLFFBQ1osdUJBQUMsT0FBRSw0QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUFJO0FBQUEsV0FIMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxPQUFDO0FBQUE7QUFBQSxRQUNrQyx1QkFBQyxPQUFFLGlDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUFJO0FBQUEsUUFDakMsdUJBQUMsT0FBRSxvQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU87QUFBQSxRQUFJO0FBQUEsUUFDNUIsdUJBQUMsT0FBRSw4Q0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsUUFBSTtBQUFBLFFBRTdDLHVCQUFDLE9BQUUsZ0RBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQUk7QUFBQSxXQUx6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUNBLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYTtBQUFBLE9BckJmO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFSjtBQUFDQyxLQTFCUUQ7QUE0QlQsZUFBZUE7QUFBSSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQm9keUNvbnRlbnRzIiwiQXBwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9BcHAuY3NzXCI7XG5pbXBvcnQgQm9keUNvbnRlbnRzIGZyb20gXCIuL0JvZHlDb250ZW50c1wiO1xuXG4vLyBIaWdoZXN0IGxldmVsIGFwcCBjb21wb25lbnRcbmZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIkFwcFwiPlxuICAgICAgPHAgY2xhc3NOYW1lPVwiQXBwLWhlYWRlclwiPlxuICAgICAgICA8aDE+TW9jazwvaDE+XG4gICAgICA8L3A+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIkFwcC1kZXNjcmlwdGlvblwiPlxuICAgICAgICA8aDM+V2l0aCB0aGlzIGZyb250LWVuZCBhcHBsaWNhdGlvbiwgd2Ugb2ZmZXIgeW91IHRoZSBvcHBvcnR1bml0eSB0byBsb2FkLFxuICAgICAgICB2aWV3LCBhbmQgc2VhcmNoIGZvciBpbnN0YW5jZXMgaW4gQ1NWcyBpbiA8aT5vdXIgbW9ja2VkIGRhdGE8L2k+LjwvaDM+XG4gICAgICAgIDxwPlxuICAgICAgICAgIFlvdSBjYW4gY2hvb3NlIHZpZXcgeW91ciBjb21tYW5kIGhpc3RvcnkgaW4gb25lIG9mIHR3byB3YXlzOntcIiBcIn1cbiAgICAgICAgICA8Yj5CcmllZiBtb2RlPC9iPiB3aWxsIGRpc3BsYXkgdGhlIHJlc3VsdHMgZm9yIGFsbCBwcmV2aW91cyBjb21tYW5kc1xuICAgICAgICAgIHJ1bi4gPGI+VmVyYm9zZSBtb2RlPC9iPiB3aWxsIGRpc3BsYXkgYm90aCB0aGUgY29tbWFuZHMgYW5kIHJlc3VsdHNcbiAgICAgICAgICBmb3IgYWxsIHByZXZpb3VzIGNvbW1hbmRzIHJ1bi5cbiAgICAgICAgPC9wPlxuICAgICAgICA8cD5cbiAgICAgICAgICBUbyBsb2FkLCBwbGVhc2UgZW50ZXIgdGhlIGNvbW1hbmQgPGI+bG9hZCBDU1ZfRklMRVBBVEg8L2I+LiBUbyB2aWV3LFxuICAgICAgICAgIHBsZWFzZSBlbnRlciB0aGUgY29tbWFuZCA8Yj52aWV3PC9iPi4gVG8gc2VhcmNoLCBwbGVhc2UgZW50ZXIgdGhlXG4gICAgICAgICAgY29tbWFuZCA8Yj5zZWFyY2ggQ09MVU1OX05BTUUgU0VBUkNIX1RFUk08L2I+LiBBbHRlcm5hdGl2ZWx5LCB5b3UgY2FuXG4gICAgICAgICAgc2VhcmNoIHdpdGggdGhlIGNvbW1hbmRcbiAgICAgICAgICA8Yj4gc2VhcmNoIENPTFVNTl9JTkRFWCBTRUFSQ0hfVEVSTTwvYj4uIEhhdmUgZnVuIVxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxCb2R5Q29udGVudHMgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sImZpbGUiOiIvVXNlcnMvYW51c2hrYWthdGFydWthL0Rlc2t0b3AvRmFsbDIwMjMvQ1NDSTAzMjAvbW9jay1ha2F0YXJ1MS1uaGFzZWxleS9zcmMvY29tcG9uZW50cy9BcHAudHN4In0=