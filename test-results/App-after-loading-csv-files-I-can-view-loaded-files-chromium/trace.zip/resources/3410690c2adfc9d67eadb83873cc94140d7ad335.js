import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BodyContents.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2014939b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/BodyContents.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2014939b"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/main.css";
import { CommandHistory } from "/src/components/DisplayWindow/CommandHistory.tsx";
import { CommandInput } from "/src/components/CommandSearch/CommandInput.tsx";
import ModeButtons from "/src/components/DisplayWindow/ModeButtons.tsx";
import CreatorsTag from "/src/components/CreatorsTag.tsx";
export default function BodyContents() {
  _s();
  const [history, setHistory] = useState([]);
  const [historyMode, setHistoryMode] = useState("brief");
  const [commandString, setCommandString] = useState("");
  return /* @__PURE__ */ jsxDEV("div", { className: "body-contents", children: [
    /* @__PURE__ */ jsxDEV(ModeButtons, { historyMode, setHistoryMode }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/BodyContents.tsx",
      lineNumber: 16,
      columnNumber: 6
    }, this),
    /* @__PURE__ */ jsxDEV(CommandHistory, { history, historyMode, commandString }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/BodyContents.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/BodyContents.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CommandInput, { history, setHistory, commandString, setCommandString }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/BodyContents.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CreatorsTag, {}, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/BodyContents.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/BodyContents.tsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
}
_s(BodyContents, "9/jIBeWOHRcR0/b6NcnCUY1+vz8=");
_c = BodyContents;
var _c;
$RefreshReg$(_c, "BodyContents");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/BodyContents.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JLOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhCTCxTQUFTQSxnQkFBZ0I7QUFDekIsT0FBTztBQUNQLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGlCQUFpQjtBQUV4Qix3QkFBd0JDLGVBQWU7QUFBQUMsS0FBQTtBQUVyQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSVIsU0FBaUMsRUFBRTtBQUVqRSxRQUFNLENBQUNTLGFBQWFDLGNBQWMsSUFBSVYsU0FBaUIsT0FBTztBQUM5RCxRQUFNLENBQUNXLGVBQWVDLGdCQUFnQixJQUFJWixTQUFpQixFQUFFO0FBRTdELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlCQUNkO0FBQUEsMkJBQUMsZUFBWSxhQUEwQixrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RTtBQUFBLElBQ3RFLHVCQUFDLGtCQUFlLFNBQWtCLGFBQTBCLGlCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlGO0FBQUEsSUFDekYsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUk7QUFBQSxJQUNKLHVCQUFDLGdCQUFhLFNBQWtCLFlBQXdCLGVBQThCLG9CQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlIO0FBQUEsSUFDekgsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhO0FBQUEsT0FMZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUE7QUFFSjtBQUFDTSxHQWhCdUJELGNBQVk7QUFBQVEsS0FBWlI7QUFBWSxJQUFBUTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJDb21tYW5kSGlzdG9yeSIsIkNvbW1hbmRJbnB1dCIsIk1vZGVCdXR0b25zIiwiQ3JlYXRvcnNUYWciLCJCb2R5Q29udGVudHMiLCJfcyIsImhpc3RvcnkiLCJzZXRIaXN0b3J5IiwiaGlzdG9yeU1vZGUiLCJzZXRIaXN0b3J5TW9kZSIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCb2R5Q29udGVudHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCJcbmltcG9ydCB7IENvbW1hbmRIaXN0b3J5IH0gZnJvbSAnLi9EaXNwbGF5V2luZG93L0NvbW1hbmRIaXN0b3J5JztcbmltcG9ydCB7IENvbW1hbmRJbnB1dCB9IGZyb20gJy4vQ29tbWFuZFNlYXJjaC9Db21tYW5kSW5wdXQnO1xuaW1wb3J0IE1vZGVCdXR0b25zIGZyb20gXCIuL0Rpc3BsYXlXaW5kb3cvTW9kZUJ1dHRvbnNcIlxuaW1wb3J0IENyZWF0b3JzVGFnIGZyb20gXCIuL0NyZWF0b3JzVGFnXCJcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQm9keUNvbnRlbnRzKCkge1xuICAvLyBMaXN0IG9mIGNvbW1hbmQsIHJlc3VsdFxuICBjb25zdCBbaGlzdG9yeSwgc2V0SGlzdG9yeV0gPSB1c2VTdGF0ZTxbc3RyaW5nLCBzdHJpbmdbXVtdXVtdPihbXSk7IFxuICAvLyBTdHJpbmcgdG8gcmVwcmVzZW50IHRoZSBtb2RlIHNlbGVjdGVkIGJ5IHRoZSB1c2VyIChlaXRoZXIgdmVyYm9zZSBvciBicmllZilcbiAgY29uc3QgW2hpc3RvcnlNb2RlLCBzZXRIaXN0b3J5TW9kZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiYnJpZWZcIilcbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9keS1jb250ZW50c1wiPiBcbiAgICAgPE1vZGVCdXR0b25zIGhpc3RvcnlNb2RlPXtoaXN0b3J5TW9kZX0gc2V0SGlzdG9yeU1vZGU9e3NldEhpc3RvcnlNb2RlfT48L01vZGVCdXR0b25zPlxuICAgICAgPENvbW1hbmRIaXN0b3J5IGhpc3Rvcnk9e2hpc3Rvcnl9IGhpc3RvcnlNb2RlPXtoaXN0b3J5TW9kZX0gY29tbWFuZFN0cmluZz17Y29tbWFuZFN0cmluZ30vPlxuICAgICAgPGhyPjwvaHI+XG4gICAgICA8Q29tbWFuZElucHV0IGhpc3Rvcnk9e2hpc3Rvcnl9IHNldEhpc3Rvcnk9e3NldEhpc3Rvcnl9IGNvbW1hbmRTdHJpbmc9e2NvbW1hbmRTdHJpbmd9IHNldENvbW1hbmRTdHJpbmc9e3NldENvbW1hbmRTdHJpbmd9Lz5cbiAgICAgIDxDcmVhdG9yc1RhZz48L0NyZWF0b3JzVGFnPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvYW51c2hrYWthdGFydWthL0Rlc2t0b3AvRmFsbDIwMjMvQ1NDSTAzMjAvbW9jay1ha2F0YXJ1MS1uaGFzZWxleS9zcmMvY29tcG9uZW50cy9Cb2R5Q29udGVudHMudHN4In0=