import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2014939b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=2014939b"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=2014939b"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import "/src/styles/index.css";
import App from "/src/components/App.tsx";
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(/* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/index.tsx",
  lineNumber: 7,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/index.tsx",
  lineNumber: 6,
  columnNumber: 13
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFWSixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsT0FBTztBQUNQLE9BQU9DLFNBQVM7QUFFaEIsTUFBTUMsT0FBT0YsU0FBU0csV0FDcEJDLFNBQVNDLGVBQWUsTUFBTSxDQUNoQztBQUNBSCxLQUFLSSxPQUNILHVCQUFDLE1BQU0sWUFBTixFQUNDLGlDQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFJLEtBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBLENBQ0YiLCJuYW1lcyI6WyJSZWFjdCIsIlJlYWN0RE9NIiwiQXBwIiwicm9vdCIsImNyZWF0ZVJvb3QiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIl0sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgJy4vc3R5bGVzL2luZGV4LmNzcyc7XG5pbXBvcnQgQXBwIGZyb20gJy4vY29tcG9uZW50cy9BcHAnO1xuXG5jb25zdCByb290ID0gUmVhY3RET00uY3JlYXRlUm9vdChcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSBhcyBIVE1MRWxlbWVudFxuKTtcbnJvb3QucmVuZGVyKFxuICA8UmVhY3QuU3RyaWN0TW9kZT5cbiAgICA8QXBwIC8+XG4gIDwvUmVhY3QuU3RyaWN0TW9kZT5cbik7Il0sImZpbGUiOiIvVXNlcnMvYW51c2hrYWthdGFydWthL0Rlc2t0b3AvRmFsbDIwMjMvQ1NDSTAzMjAvbW9jay1ha2F0YXJ1MS1uaGFzZWxleS9zcmMvaW5kZXgudHN4In0=