import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CommandSearch/SearchBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2014939b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/SearchBar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function SearchBar({
  value,
  setValue,
  ariaLabel
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "search-bar", value, placeholder: "Enter command here!", onChange: (ev) => setValue(ev.target.value), "aria-label": ariaLabel }, void 0, false, {
    fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/SearchBar.tsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
}
_c = SearchBar;
var _c;
$RefreshReg$(_c, "SearchBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/SearchBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07QUFaTixPQUFPO0FBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVVyQixnQkFBU0EsVUFBVTtBQUFBLEVBQUNDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQVVDO0FBQXlCLEdBQUc7QUFDdEUsU0FDRSx1QkFBQyxXQUFNLE1BQUssUUFBTyxXQUFVLGNBQ3ZCLE9BQ0EsYUFBWSx1QkFDWixVQUFXQyxRQUFPRixTQUFTRSxHQUFHQyxPQUFPSixLQUFLLEdBQzFDLGNBQVlFLGFBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUVKO0FBQUNHLEtBVGVOO0FBQVMsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNlYXJjaEJhciIsInZhbHVlIiwic2V0VmFsdWUiLCJhcmlhTGFiZWwiLCJldiIsInRhcmdldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2VhcmNoQmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uLy4uL3N0eWxlcy9tYWluLmNzcydcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gJ3JlYWN0JztcblxuaW50ZXJmYWNlIFNlYXJjaEJhclByb3BzIHtcbiAgICB2YWx1ZTogc3RyaW5nLCBcbiAgICBzZXRWYWx1ZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nPj4sXG4gICAgYXJpYUxhYmVsOiBzdHJpbmcgXG4gIH1cbiAgXG4gIC8vIENvbXBvbmVudCB0aGF0IGJ1aWxkcyB0aGUgc2VhcmNoIGJhclxuICBleHBvcnQgZnVuY3Rpb24gU2VhcmNoQmFyKHt2YWx1ZSwgc2V0VmFsdWUsIGFyaWFMYWJlbH06IFNlYXJjaEJhclByb3BzKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzTmFtZT1cInNlYXJjaC1iYXJcIlxuICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfSBcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgY29tbWFuZCBoZXJlIVwiXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2KSA9PiBzZXRWYWx1ZShldi50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YXJpYUxhYmVsfT5cbiAgICAgIDwvaW5wdXQ+XG4gICAgKTtcbiAgfSJdLCJmaWxlIjoiL1VzZXJzL2FudXNoa2FrYXRhcnVrYS9EZXNrdG9wL0ZhbGwyMDIzL0NTQ0kwMzIwL21vY2stYWthdGFydTEtbmhhc2VsZXkvc3JjL2NvbXBvbmVudHMvQ29tbWFuZFNlYXJjaC9TZWFyY2hCYXIudHN4In0=