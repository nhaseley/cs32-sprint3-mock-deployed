import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CommandSearch/CommandInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2014939b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/CommandInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=2014939b"; const useState = __vite__cjsImport4_react["useState"];
import { SearchBar } from "/src/components/CommandSearch/SearchBar.tsx";
import { MockLoadOutputs, MockViewOutputs, MockSearchOutputs } from "/mock-data/mockedJson.ts";
export function CommandInput(props) {
  _s();
  const lastCommand = props.commandString;
  const [currentFile, setCurrentFile] = useState("");
  const loadData = MockLoadOutputs;
  const viewData = MockViewOutputs;
  const searchData = MockSearchOutputs;
  function handleSubmit() {
    let result = lastCommand && lastCommand.length >= 4 ? lastCommand.slice(0, 5) === "load " ? loadData[lastCommand.slice(5)] || "No mocked data for this csv." : lastCommand.slice(0, 4) === "view" ? viewData[currentFile] || "No csv loaded yet." : lastCommand.slice(0, 7) === "search " ? !currentFile ? [["No csv loaded yet."]] : searchData[currentFile][lastCommand] || [["No matches from the loaded csv."]] : [["No mocked data found."]] : [["Invalid command."]];
    props.commandString != "" ? props.setHistory([...props.history, [props.commandString, result]]) : props.setHistory([...props.history, [props.commandString, [["Please input a command."]]]]);
    props.setCommandString("");
    setCurrentFile(props.commandString.slice(0, 4) == "load" ? props.commandString.split(" ")[1] : currentFile);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "command-input", children: /* @__PURE__ */ jsxDEV("fieldset", { className: "command-fieldset", children: [
    /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/CommandInput.tsx",
      lineNumber: 43,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(SearchBar, { value: props.commandString, setValue: props.setCommandString, ariaLabel: "Command input" }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/CommandInput.tsx",
      lineNumber: 44,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "submit-button", onClick: () => handleSubmit(), children: "Submit" }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/CommandInput.tsx",
      lineNumber: 45,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/CommandInput.tsx",
    lineNumber: 42,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/CommandInput.tsx",
    lineNumber: 41,
    columnNumber: 10
  }, this);
}
_s(CommandInput, "RWs63IfUsGkQDEsat3+NrjLMiBM=");
_c = CommandInput;
var _c;
$RefreshReg$(_c, "CommandInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CommandSearch/CommandInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBFUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyxpQkFBaUI7QUFDMUIsU0FDRUMsaUJBQ0FDLGlCQUNBQyx5QkFDSztBQVVBLGdCQUFTQyxhQUFhQyxPQUEwQjtBQUFBQyxLQUFBO0FBRXJELFFBQU1DLGNBQXNCRixNQUFNRztBQUVsQyxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSVgsU0FBUyxFQUFFO0FBRWpELFFBQU1ZLFdBQVdWO0FBQ2pCLFFBQU1XLFdBQVdWO0FBQ2pCLFFBQU1XLGFBQWFWO0FBV25CLFdBQVNXLGVBQWU7QUFDdEIsUUFBSUMsU0FDRlIsZUFBZUEsWUFBWVMsVUFBVSxJQUNqQ1QsWUFBWVUsTUFBTSxHQUFHLENBQUMsTUFBTSxVQUMxQk4sU0FBU0osWUFBWVUsTUFBTSxDQUFDLENBQUMsS0FBSyxpQ0FDbENWLFlBQVlVLE1BQU0sR0FBRyxDQUFDLE1BQU0sU0FDNUJMLFNBQVNILFdBQVcsS0FBSyx1QkFDekJGLFlBQVlVLE1BQU0sR0FBRyxDQUFDLE1BQU0sWUFDNUIsQ0FBQ1IsY0FDQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsSUFDdkJJLFdBQVdKLFdBQVcsRUFBRUYsV0FBVyxLQUNuQyxDQUFDLENBQUMsaUNBQWlDLENBQUMsSUFDdEMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLElBQzVCLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUUzQkYsVUFBTUcsaUJBQWlCLEtBQ25CSCxNQUFNYSxXQUFXLENBQUMsR0FBR2IsTUFBTWMsU0FBUyxDQUFDZCxNQUFNRyxlQUFlTyxNQUFNLENBQUMsQ0FBQyxJQUNsRVYsTUFBTWEsV0FBVyxDQUNmLEdBQUdiLE1BQU1jLFNBQ1QsQ0FBQ2QsTUFBTUcsZUFBZSxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLENBQ3JEO0FBQ0xILFVBQU1lLGlCQUFpQixFQUFFO0FBQ3pCVixtQkFDRUwsTUFBTUcsY0FBY1MsTUFBTSxHQUFHLENBQUMsS0FBSyxTQUMvQlosTUFBTUcsY0FBY2EsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNoQ1osV0FDTjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxjQUFTLFdBQVUsb0JBQ2xCO0FBQUEsMkJBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCO0FBQUEsSUFDeEIsdUJBQUMsYUFDQyxPQUFPSixNQUFNRyxlQUNiLFVBQVVILE1BQU1lLGtCQUNoQixXQUFXLG1CQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHNkI7QUFBQSxJQUU3Qix1QkFBQyxZQUFPLFdBQVUsaUJBQWdCLFNBQVMsTUFBTU4sYUFBYSxHQUFFLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQTtBQUVKO0FBQUNSLEdBL0RlRixjQUFZO0FBQUFrQixLQUFabEI7QUFBWSxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2VhcmNoQmFyIiwiTW9ja0xvYWRPdXRwdXRzIiwiTW9ja1ZpZXdPdXRwdXRzIiwiTW9ja1NlYXJjaE91dHB1dHMiLCJDb21tYW5kSW5wdXQiLCJwcm9wcyIsIl9zIiwibGFzdENvbW1hbmQiLCJjb21tYW5kU3RyaW5nIiwiY3VycmVudEZpbGUiLCJzZXRDdXJyZW50RmlsZSIsImxvYWREYXRhIiwidmlld0RhdGEiLCJzZWFyY2hEYXRhIiwiaGFuZGxlU3VibWl0IiwicmVzdWx0IiwibGVuZ3RoIiwic2xpY2UiLCJzZXRIaXN0b3J5IiwiaGlzdG9yeSIsInNldENvbW1hbmRTdHJpbmciLCJzcGxpdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29tbWFuZElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi8uLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFNlYXJjaEJhciB9IGZyb20gXCIuL1NlYXJjaEJhclwiO1xuaW1wb3J0IHtcbiAgTW9ja0xvYWRPdXRwdXRzLFxuICBNb2NrVmlld091dHB1dHMsXG4gIE1vY2tTZWFyY2hPdXRwdXRzLFxufSBmcm9tIFwiLi4vLi4vLi4vbW9jay1kYXRhL21vY2tlZEpzb25cIjsgLy8gQWxsIG91ciBtb2NrZWQgZGF0YVxuXG5pbnRlcmZhY2UgQ29tbWFuZElucHV0UHJvcHMge1xuICBoaXN0b3J5OiBbc3RyaW5nLCBzdHJpbmdbXVtdXVtdO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxbc3RyaW5nLCBzdHJpbmdbXVtdXVtdPj47XG4gIGNvbW1hbmRTdHJpbmc6IHN0cmluZztcbiAgc2V0Q29tbWFuZFN0cmluZzogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nPj47XG59XG5cbi8vIENvbXBvbmVudCB0aGF0IG1hbmFnZXMgdGhlIGNvbnRlbnRzIG9mIHRoZSBpbnB1dCBib3hcbmV4cG9ydCBmdW5jdGlvbiBDb21tYW5kSW5wdXQocHJvcHM6IENvbW1hbmRJbnB1dFByb3BzKSB7XG5cbiAgY29uc3QgbGFzdENvbW1hbmQ6IHN0cmluZyA9IHByb3BzLmNvbW1hbmRTdHJpbmc7XG4gIC8vIFN0YXRlIGZvciB0aGUgY3VycmVudCBmaWxlcGF0aCBiZWluZyBsb2FkZWRcbiAgY29uc3QgW2N1cnJlbnRGaWxlLCBzZXRDdXJyZW50RmlsZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgLy8gRXh0cmFjdCBtb2NrZWQgZGF0YSBmb3IgbG9hZCwgdmlldywgYW5kIHNlYXJjaFxuICBjb25zdCBsb2FkRGF0YSA9IE1vY2tMb2FkT3V0cHV0cztcbiAgY29uc3Qgdmlld0RhdGEgPSBNb2NrVmlld091dHB1dHM7XG4gIGNvbnN0IHNlYXJjaERhdGEgPSBNb2NrU2VhcmNoT3V0cHV0cztcblxuICAvKipcbiAgICogRnVuY3Rpb24gdGhhdCBoYW5kbGVzIHdoZW4gdGhlIHNlYXJjaCBidXR0b24gaXMgcHJlc3NlZCBieSB0aGUgdXNlclxuICAgKiBHcmFicyB0aGUgY29ycmVzcG9uZGluZyByZXN1bHQgdmFsdWUgZm9yIHZhbGlkIGxvYWQsIHZpZXcgYW5kIHNlYXJjaFxuICAgKiBjb21tYW5kcyBpbiBvdXIgbW9ja2VkIGRhdGFcbiAgICogRGlzcGxheXMgZXJyb3IgbWVzc2FnZXMgaWYgcmVxdWVzdCBvciByZXNwb25zZSBpcyBpbnZhbGlkXG4gICAqIFVwZGF0ZXMgdGhlIGhpc3Rvcnkgb2YgY29tbWFuZHMgdG8gaW5jbHVkZSB0aGUgcmVxdWVzdCBqdXN0IHNlbnRcbiAgICogSWYgd2UgYXJlIGxvYWRpbmcgYSBuZXcgZmlsZSwgdXBkYXRlcyB0aGUgY3VycmVudEZpbGUgc3RhdGUgdG8gdGhlXG4gICAqIGZpbGUgdGhlIHVzZXIgaXMgbG9hZGluZ1xuICAgKi9cbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KCkge1xuICAgIGxldCByZXN1bHQ6IHN0cmluZ1tdW10gPVxuICAgICAgbGFzdENvbW1hbmQgJiYgbGFzdENvbW1hbmQubGVuZ3RoID49IDRcbiAgICAgICAgPyBsYXN0Q29tbWFuZC5zbGljZSgwLCA1KSA9PT0gXCJsb2FkIFwiXG4gICAgICAgICAgPyBsb2FkRGF0YVtsYXN0Q29tbWFuZC5zbGljZSg1KV0gfHwgXCJObyBtb2NrZWQgZGF0YSBmb3IgdGhpcyBjc3YuXCJcbiAgICAgICAgICA6IGxhc3RDb21tYW5kLnNsaWNlKDAsIDQpID09PSBcInZpZXdcIlxuICAgICAgICAgID8gdmlld0RhdGFbY3VycmVudEZpbGVdIHx8IFwiTm8gY3N2IGxvYWRlZCB5ZXQuXCJcbiAgICAgICAgICA6IGxhc3RDb21tYW5kLnNsaWNlKDAsIDcpID09PSBcInNlYXJjaCBcIlxuICAgICAgICAgID8gIWN1cnJlbnRGaWxlXG4gICAgICAgICAgICA/IFtbXCJObyBjc3YgbG9hZGVkIHlldC5cIl1dXG4gICAgICAgICAgICA6IHNlYXJjaERhdGFbY3VycmVudEZpbGVdW2xhc3RDb21tYW5kXSB8fFxuICAgICAgICAgICAgICBbW1wiTm8gbWF0Y2hlcyBmcm9tIHRoZSBsb2FkZWQgY3N2LlwiXV1cbiAgICAgICAgICA6IFtbXCJObyBtb2NrZWQgZGF0YSBmb3VuZC5cIl1dXG4gICAgICAgIDogW1tcIkludmFsaWQgY29tbWFuZC5cIl1dO1xuXG4gICAgcHJvcHMuY29tbWFuZFN0cmluZyAhPSBcIlwiXG4gICAgICA/IHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIFtwcm9wcy5jb21tYW5kU3RyaW5nLCByZXN1bHRdXSlcbiAgICAgIDogcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgICAgICBbcHJvcHMuY29tbWFuZFN0cmluZywgW1tcIlBsZWFzZSBpbnB1dCBhIGNvbW1hbmQuXCJdXV0sXG4gICAgICAgIF0pO1xuICAgIHByb3BzLnNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gICAgc2V0Q3VycmVudEZpbGUoXG4gICAgICBwcm9wcy5jb21tYW5kU3RyaW5nLnNsaWNlKDAsIDQpID09IFwibG9hZFwiXG4gICAgICAgID8gcHJvcHMuY29tbWFuZFN0cmluZy5zcGxpdChcIiBcIilbMV1cbiAgICAgICAgOiBjdXJyZW50RmlsZVxuICAgICk7IC8vIEdyYWIgb25seSB0aGUgdXJsIGlmIHdlIGFyZSBsb2FkaW5nXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29tbWFuZC1pbnB1dFwiPlxuICAgICAgPGZpZWxkc2V0IGNsYXNzTmFtZT1cImNvbW1hbmQtZmllbGRzZXRcIj5cbiAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XG4gICAgICAgIDxTZWFyY2hCYXJcbiAgICAgICAgICB2YWx1ZT17cHJvcHMuY29tbWFuZFN0cmluZ31cbiAgICAgICAgICBzZXRWYWx1ZT17cHJvcHMuc2V0Q29tbWFuZFN0cmluZ31cbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBpbnB1dFwifVxuICAgICAgICAvPlxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInN1Ym1pdC1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoKX0+XG4gICAgICAgICAgU3VibWl0XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9maWVsZHNldD5cbiAgICA8L2Rpdj5cbiAgKTtcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9hbnVzaGtha2F0YXJ1a2EvRGVza3RvcC9GYWxsMjAyMy9DU0NJMDMyMC9tb2NrLWFrYXRhcnUxLW5oYXNlbGV5L3NyYy9jb21wb25lbnRzL0NvbW1hbmRTZWFyY2gvQ29tbWFuZElucHV0LnRzeCJ9