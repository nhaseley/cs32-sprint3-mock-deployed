import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DisplayWindow/ModeButtons.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2014939b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/ModeButtons.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export default function ModeButtons(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "mode-buttons", children: [
    /* @__PURE__ */ jsxDEV("button", { className: "brief-button", onClick: () => {
      props.setHistoryMode("brief");
    }, style: {
      border: props.historyMode === "brief" ? "0.5vw solid #213547" : "none",
      backgroundColor: props.historyMode === "brief" ? "#A52A2A" : "darkblue"
    }, children: " Brief " }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/ModeButtons.tsx",
      lineNumber: 11,
      columnNumber: 6
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "verbose-button", onClick: () => {
      props.setHistoryMode("verbose");
    }, style: {
      border: props.historyMode === "verbose" ? "0.5vw solid #213547" : "none",
      backgroundColor: props.historyMode === "verbose" ? "#A52A2A" : "darkblue"
    }, children: " Verbose " }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/ModeButtons.tsx",
      lineNumber: 17,
      columnNumber: 6
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/ModeButtons.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_c = ModeButtons;
var _c;
$RefreshReg$(_c, "ModeButtons");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/ModeButtons.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYUs7QUFiTCwyQkFBbUJBO0FBQXNCLE1BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxPQUFPO0FBUVAsd0JBQXdCQyxZQUFZQyxPQUEwQjtBQUU1RCxTQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFDZDtBQUFBLDJCQUFDLFlBQ0QsV0FBVSxnQkFDVixTQUFTLE1BQU07QUFDZEEsWUFBTUMsZUFBZSxPQUFPO0FBQUEsSUFDOUIsR0FDQSxPQUFPO0FBQUEsTUFDTEMsUUFBUUYsTUFBTUcsZ0JBQWdCLFVBQVUsd0JBQXdCO0FBQUEsTUFDaEVDLGlCQUFpQkosTUFBTUcsZ0JBQWdCLFVBQVUsWUFBWTtBQUFBLElBRS9ELEdBQ0gsdUJBVkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVHO0FBQUEsSUFDSCx1QkFBQyxZQUNELFdBQVUsa0JBQ1YsU0FBUyxNQUFNO0FBQ2RILFlBQU1DLGVBQWUsU0FBUztBQUFBLElBQ2hDLEdBQ0EsT0FBTztBQUFBLE1BQ0xDLFFBQVFGLE1BQU1HLGdCQUFnQixZQUFZLHdCQUF3QjtBQUFBLE1BQ2xFQyxpQkFBaUJKLE1BQU1HLGdCQUFnQixZQUFZLFlBQVk7QUFBQSxJQUNqRSxHQUNILHlCQVRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTSztBQUFBLE9BckJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFSjtBQUFDRSxLQTNCdUJOO0FBQVcsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNldFN0YXRlQWN0aW9uIiwiTW9kZUJ1dHRvbnMiLCJwcm9wcyIsInNldEhpc3RvcnlNb2RlIiwiYm9yZGVyIiwiaGlzdG9yeU1vZGUiLCJiYWNrZ3JvdW5kQ29sb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1vZGVCdXR0b25zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24gfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCAnLi4vLi4vc3R5bGVzL21haW4uY3NzJztcblxuaW50ZXJmYWNlIE1vZGVCdXR0b25zUHJvcHN7XG4gIGhpc3RvcnlNb2RlOiBzdHJpbmc7XG4gIHNldEhpc3RvcnlNb2RlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+Pjtcbn1cblxuLy8gQ29tcG9uZW50IHdpdGggYnV0dG9ucyB0byBzd2FwIGJldHdlZW4gdXNlcidzIGRlc2lyZWQgaGlzdG9yeSBtb2RlIHRvIGRpc3BsYXlcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1vZGVCdXR0b25zKHByb3BzIDogTW9kZUJ1dHRvbnNQcm9wcykge1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtb2RlLWJ1dHRvbnNcIj4gXG4gICAgIDxidXR0b24gXG4gICAgIGNsYXNzTmFtZT1cImJyaWVmLWJ1dHRvblwiIFxuICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICBwcm9wcy5zZXRIaXN0b3J5TW9kZShcImJyaWVmXCIpO1xuICAgIH19XG4gICAgc3R5bGU9e3tcbiAgICAgIGJvcmRlcjogcHJvcHMuaGlzdG9yeU1vZGUgPT09IFwiYnJpZWZcIiA/IFwiMC41dncgc29saWQgIzIxMzU0N1wiIDogXCJub25lXCIsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IHByb3BzLmhpc3RvcnlNb2RlID09PSBcImJyaWVmXCIgPyBcIiNBNTJBMkFcIiA6IFwiZGFya2JsdWVcIixcblxuICAgIH19XG4+IEJyaWVmIDwvYnV0dG9uPlxuICAgICA8YnV0dG9uIFxuICAgICBjbGFzc05hbWU9XCJ2ZXJib3NlLWJ1dHRvblwiIFxuICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICBwcm9wcy5zZXRIaXN0b3J5TW9kZShcInZlcmJvc2VcIik7XG4gICAgfX0gICAgIFxuICAgIHN0eWxlPXt7XG4gICAgICBib3JkZXI6IHByb3BzLmhpc3RvcnlNb2RlID09PSBcInZlcmJvc2VcIiA/IFwiMC41dncgc29saWQgIzIxMzU0N1wiIDogXCJub25lXCIsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IHByb3BzLmhpc3RvcnlNb2RlID09PSBcInZlcmJvc2VcIiA/IFwiI0E1MkEyQVwiIDogXCJkYXJrYmx1ZVwiLFxuICAgIH19XG4+IFZlcmJvc2UgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59Il0sImZpbGUiOiIvVXNlcnMvYW51c2hrYWthdGFydWthL0Rlc2t0b3AvRmFsbDIwMjMvQ1NDSTAzMjAvbW9jay1ha2F0YXJ1MS1uaGFzZWxleS9zcmMvY29tcG9uZW50cy9EaXNwbGF5V2luZG93L01vZGVCdXR0b25zLnRzeCJ9