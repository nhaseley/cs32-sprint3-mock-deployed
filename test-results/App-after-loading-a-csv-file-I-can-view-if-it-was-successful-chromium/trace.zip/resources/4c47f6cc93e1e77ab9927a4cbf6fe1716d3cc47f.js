import {
  require_react
} from "/node_modules/.vite/deps/chunk-UZX524IT.js?v=2014939b";
export default require_react();
//# sourceMappingURL=react.js.map
