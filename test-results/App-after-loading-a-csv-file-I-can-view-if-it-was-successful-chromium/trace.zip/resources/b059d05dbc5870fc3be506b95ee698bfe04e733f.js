import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CreatorsTag.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2014939b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CreatorsTag.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function CreatorsTag() {
  return /* @__PURE__ */ jsxDEV("p", { className: "creators-tag", children: "Created by Nya Haseley-Ayende and Anushka Kataruka for CS32: Software Engineering @ Brown" }, void 0, false, {
    fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CreatorsTag.tsx",
    lineNumber: 2,
    columnNumber: 10
  }, this);
}
_c = CreatorsTag;
var _c;
$RefreshReg$(_c, "CreatorsTag");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/CreatorsTag.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBRUk7QUFGSiwyQkFBd0JBO0FBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3BDLFNBQ0UsdUJBQUMsT0FBRSxXQUFVLGdCQUFlLHlHQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDQyxLQVB1QkQ7QUFBVyxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ3JlYXRvcnNUYWciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNyZWF0b3JzVGFnLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDcmVhdG9yc1RhZygpIHtcbiAgcmV0dXJuIChcbiAgICA8cCBjbGFzc05hbWU9XCJjcmVhdG9ycy10YWdcIj4gXG4gICAgICBDcmVhdGVkIGJ5IE55YSBIYXNlbGV5LUF5ZW5kZSBhbmQgQW51c2hrYSBLYXRhcnVrYSBcbiAgICAgIGZvciBDUzMyOiBTb2Z0d2FyZSBFbmdpbmVlcmluZyBAIEJyb3duXG4gICAgPC9wPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvYW51c2hrYWthdGFydWthL0Rlc2t0b3AvRmFsbDIwMjMvQ1NDSTAzMjAvbW9jay1ha2F0YXJ1MS1uaGFzZWxleS9zcmMvY29tcG9uZW50cy9DcmVhdG9yc1RhZy50c3gifQ==