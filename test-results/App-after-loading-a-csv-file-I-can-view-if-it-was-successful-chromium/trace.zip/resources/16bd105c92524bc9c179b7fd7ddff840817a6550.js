import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DisplayWindow/CommandHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2014939b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function CommandHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "command-history", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: " Your Previous Commands: " }, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
      lineNumber: 11,
      columnNumber: 7
    }, this),
    " ",
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
      lineNumber: 11,
      columnNumber: 42
    }, this),
    props.history.map((command, index) => /* @__PURE__ */ jsxDEV("div", { className: "datum", children: [
      props.historyMode === "verbose" ? /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
          "Command:",
          " " + command[0]
        ] }, void 0, true, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
          lineNumber: 14,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "result", children: " Output:" }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
          lineNumber: 18,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
        lineNumber: 13,
        columnNumber: 46
      }, this) : null,
      command[1][0].length != 1 ? (
        // more than 1 column in result, so display as a table
        /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tbody", { children: command[1].map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
          lineNumber: 26,
          columnNumber: 51
        }, this)) }, rowIndex, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
          lineNumber: 25,
          columnNumber: 52
        }, this)) }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
          lineNumber: 24,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
          lineNumber: 23,
          columnNumber: 7
        }, this)
      ) : " " + command[1],
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
        lineNumber: 30,
        columnNumber: 11
      }, this)
    ] }, index, true, {
      fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
      lineNumber: 12,
      columnNumber: 46
    }, this))
  ] }, void 0, true, {
    fileName: "/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_c = CommandHistory;
var _c;
$RefreshReg$(_c, "CommandHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/anushkakataruka/Desktop/Fall2023/CSCI0320/mock-akataru1-nhaseley/src/components/DisplayWindow/CommandHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07QUFaTixPQUFPO0FBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVN2QixnQkFBU0EsZUFBZUMsT0FBNEI7QUFDekQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwyQkFBQyxRQUFHLHlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkI7QUFBQSxJQUFLO0FBQUEsSUFBQyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSTtBQUFBLElBQ3RDQSxNQUFNQyxRQUFRQyxJQUFJLENBQUNDLFNBQVNDLFVBQzNCLHVCQUFDLFNBQUksV0FBVSxTQUNaSjtBQUFBQSxZQUFNSyxnQkFBZ0IsWUFDckIsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFNBQUksV0FBVSxXQUFTO0FBQUE7QUFBQSxVQUVyQixNQUFNRixRQUFRLENBQUM7QUFBQSxhQUZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxVQUFTLHdCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUEsV0FMaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLElBQ0U7QUFBQSxNQUVIQSxRQUFRLENBQUMsRUFBRSxDQUFDLEVBQUVHLFVBQVU7QUFBQTtBQUFBLFFBRXZCLHVCQUFDLFdBQ0MsaUNBQUMsV0FDRUgsa0JBQVEsQ0FBQyxFQUFFRCxJQUFJLENBQUNLLEtBQUtDLGFBQ3BCLHVCQUFDLFFBQ0VELGNBQUlMLElBQUksQ0FBQ08sTUFBTUMsY0FDZCx1QkFBQyxRQUFvQkQsa0JBQVpDLFdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQixDQUMzQixLQUhNRixVQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxDQUNELEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsVUFFQSxNQUFNTCxRQUFRLENBQUM7QUFBQSxNQUVqQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSTtBQUFBLFNBM0JzQkMsT0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQSxDQUNEO0FBQUEsT0FoQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVKO0FBQUNPLEtBckNlWjtBQUFjLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDb21tYW5kSGlzdG9yeSIsInByb3BzIiwiaGlzdG9yeSIsIm1hcCIsImNvbW1hbmQiLCJpbmRleCIsImhpc3RvcnlNb2RlIiwibGVuZ3RoIiwicm93Iiwicm93SW5kZXgiLCJjZWxsIiwiY2VsbEluZGV4IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb21tYW5kSGlzdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vLi4vc3R5bGVzL21haW4uY3NzXCI7XG5cbmludGVyZmFjZSBDb21tYW5kSGlzdG9yeVByb3BzIHtcbiAgaGlzdG9yeTogW3N0cmluZywgc3RyaW5nW11bXV1bXTtcbiAgaGlzdG9yeU1vZGU6IHN0cmluZztcbiAgY29tbWFuZFN0cmluZzogc3RyaW5nOyAvLyBjdXJyZW50IGNvbW1hbmQgYmVpbmcgdHlwZWQgYnkgdXNlclxufVxuXG4vLyBDb21wb25lbnQgdG8gZGlzcGxheSBhbGwgY29tbWFuZCBoaXN0b3J5XG5leHBvcnQgZnVuY3Rpb24gQ29tbWFuZEhpc3RvcnkocHJvcHM6IENvbW1hbmRIaXN0b3J5UHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbW1hbmQtaGlzdG9yeVwiPlxuICAgICAgPGgyPiBZb3VyIFByZXZpb3VzIENvbW1hbmRzOiA8L2gyPiA8aHI+PC9ocj5cbiAgICAgIHtwcm9wcy5oaXN0b3J5Lm1hcCgoY29tbWFuZCwgaW5kZXgpID0+IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXR1bVwiIGtleT17aW5kZXh9PlxuICAgICAgICAgIHtwcm9wcy5oaXN0b3J5TW9kZSA9PT0gXCJ2ZXJib3NlXCIgPyAoXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbW1hbmRcIj5cbiAgICAgICAgICAgICAgICBDb21tYW5kOlxuICAgICAgICAgICAgICAgIHtcIiBcIiArIGNvbW1hbmRbMF19XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyZXN1bHRcIj4gT3V0cHV0OjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiBudWxsfVxuXG4gICAgICAgICAge2NvbW1hbmRbMV1bMF0ubGVuZ3RoICE9IDEgPyAoIFxuICAgICAgICAgICAgLy8gbW9yZSB0aGFuIDEgY29sdW1uIGluIHJlc3VsdCwgc28gZGlzcGxheSBhcyBhIHRhYmxlXG4gICAgICAgICAgICA8dGFibGU+XG4gICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICB7Y29tbWFuZFsxXS5tYXAoKHJvdywgcm93SW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3Jvd0luZGV4fT5cbiAgICAgICAgICAgICAgICAgICAge3Jvdy5tYXAoKGNlbGwsIGNlbGxJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBrZXk9e2NlbGxJbmRleH0+e2NlbGx9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgXCIgXCIgKyBjb21tYW5kWzFdXG4gICAgICAgICAgKX1cbiAgICAgICAgICA8aHI+PC9ocj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FudXNoa2FrYXRhcnVrYS9EZXNrdG9wL0ZhbGwyMDIzL0NTQ0kwMzIwL21vY2stYWthdGFydTEtbmhhc2VsZXkvc3JjL2NvbXBvbmVudHMvRGlzcGxheVdpbmRvdy9Db21tYW5kSGlzdG9yeS50c3gifQ==